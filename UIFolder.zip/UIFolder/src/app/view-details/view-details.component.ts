import { Component, OnInit,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { ViewDetailsService } from './view-details.service';
import { MatIconModule } from '@angular/material/icon'; 
import { DetailsforidComponent } from '../detailsforid/detailsforid.component';
import { MatDialog } from '@angular/material/dialog';
import {MatGridListModule} from '@angular/material/grid-list';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrl: './view-details.component.css',
})

export class ViewDetailsComponent implements OnInit {

  loginForm: any;
  
  filter:any;

  displayedColumns: string[] = ['firstname', 'lastname','gender','ContactNumber','email',
  'designation','dateofBirth','age','Photo','Country','State','City','pincode','edit'];
  dataSource = new MatTableDataSource([]);

  cars: any = [
    {value: 'Female', viewValue: 'Female'},
    {value: 'male', viewValue: 'male'},
  ];

  Countries: any = [
    {value: 'India', viewValue: 'India'},
    {value: 'USA', viewValue: 'USA'},
    {value: 'UK', viewValue: 'UK'},
  ];

  States:any=[
    {value: 'Maharashtra', viewValue: 'Maharashtra',country:"India"},
    {value: 'California', viewValue: 'California',country:"USA"},
    {value: 'London', viewValue: 'London',country:"UK"},
    {value: 'Karnataka', viewValue: 'Karnataka',country:"India"},
    
  ];

  city:any=[
    {value: 'Mumbai', viewValue: 'Mumbai',country:"India",state:"Maharashtra"},
    {value: 'Orange county', viewValue: 'Orange county',country:"USA",state:"California"},
  ];

  StateSelection:any =[];
  cityselection:any=[];
  fileName = '';
  constructor(public Restiration:ViewDetailsService,public dialog:MatDialog){

  }
    
  ngOnInit() {
        this.loginForm = new FormGroup({
            firstname: new FormControl("", Validators.required),
            lastname: new FormControl("",Validators.required),
            gender:new FormControl("",Validators.required),
            ContactNumber:new FormControl("",Validators.required),
            email:new FormControl("",Validators.required),
            designation:new FormControl("",Validators.required),
            dateofBirth:new FormControl("",Validators.required),
            age :new FormControl("",Validators.required),
            Photo:new FormControl(""),
            Country: new FormControl("",Validators.required),
            State :new FormControl("",Validators.required),
            City:new FormControl("",Validators.required),
            pincode:new FormControl("",Validators.required),

        });

        this.GetUsersdata();
    }
    
    registration() {
       
      let submitform={
        "firstname":this.loginForm.get("firstname").value,
        "lastname":this.loginForm.get("lastname").value,
        "gender":this.loginForm.get("gender").value,
        "ContactNumber":Number(this.loginForm.get("ContactNumber").value),
        "email":this.loginForm.get("email").value,
        "designation":this.loginForm.get("designation").value,
        "dateofBirth":this.loginForm.get("dateofBirth").value,
        "age":this.loginForm.get("age").value,
        "Photo": this.fileName,
        "Country":this.loginForm.get("Country").value,
        "State":this.loginForm.get("State").value,
        "City":this.loginForm.get("City").value,
        "pincode":this.loginForm.get("pincode").value,
      
      }

      console.log("data",submitform);
      this.apiCall(submitform);
    }


    apiCall(submitform:any){
      this.Restiration.addData(submitform).subscribe((data)=>{
        console.log(data);
        this.GetUsersdata();
      });
    }

    GetUsersdata(){
       this.Restiration.getData().subscribe((data)=>{
        console.log("data",data);
        this.dataSource= new MatTableDataSource(data?.data);

       });
    }

    Edit(id:any){
      this.Restiration.EditData(id).subscribe((data)=>{
        console.log("data",data);

        let dialogRef = this.dialog.open(DetailsforidComponent, {
          height: '500px',
          width: '1000px',
          
          data:data?.data
        });
        dialogRef.afterClosed().subscribe(result => {
          this.GetUsersdata();
        });

       });
      
      
      
}

ChangeState(country:any){
  this.StateSelection = this.States.filter((p :any)=> p.country ===country );
}


applyFilter(event: any) {

  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();
}



dateofBirthChange(){
    console.log("event");

}

selectCountry($event :any){
   let country =$event;

    this.StateSelection= this.States.filter((entry:any)=> entry.country === country);
    this.cityselection= this.city.filter((entry:any)=> entry.country === country);

}

selectState($event :any){
  let state =$event;
  this.cityselection= this.city.filter((entry:any)=> entry.state === state);

}

selectDOB($event :any){
let birthdate = new Date($event.value);
let age=0;

  if(birthdate){
    const timeDiff = Math.abs(Date.now() - birthdate.getTime() );
    age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365);
}
this.loginForm.get("age").setValue(age);
}


onFilechange(event:any) {

  const file:File = event.target.files[0];

  if (file) {

      this.fileName = file.name;

      const formData = new FormData();

      formData.append("thumbnail", file);
       console.log(formData);
  }
}

upload(){}



Clear(){
  this.loginForm.reset();
  this.fileName="";
}
}
