const express = require("express");
const {
  getAllUser,
  createUser,
  getUserById,
  updateUser,
} = require("../curdNodeStack/UserController");
 
const router = express.Router();
 
router.route("/").get(getAllUser).post(createUser);
router.route("/:id").get(getUserById).put(updateUser);
 
module.exports = router;