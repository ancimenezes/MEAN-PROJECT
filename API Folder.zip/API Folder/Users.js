const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const nanoid =require('nanoid');

const UserSchema = new Schema({
  firstname: String,
  lastname: String,
  gender: String,
  ContactNumber: Number,
  email: String,
  designation: String,
  dateofBirth: String,
  age: Number,
  Photo: String,
  Country: String,
  State: String,
  City: String,
  pincode: Number,
  Photo:String,
});

module.exports = mongoose.model("Users", UserSchema);