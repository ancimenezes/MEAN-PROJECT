import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AnyKeys } from 'mongoose';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ViewDetailsService {

  constructor(private http:HttpClient ) { }

  addData(data: any): Observable<any> {
    return this.http.post<any>("http://localhost:3001/api/Users", data);
      
  }

   getData():Observable<any> {
    return this.http.get("http://localhost:3001/api/Users");
   }

   EditData(id :any):Observable<any> {
    return this.http.get("http://localhost:3001/api/Users/"+id);
   }

   updateData(data2 :any,data:any):Observable<any> {
    return this.http.put("http://localhost:3001/api/Users/"+data2._id,data);
   }


      
  // API url 
  baseApiUrl = "https://file.io"
    
  
  // Returns an observable 
  upload(file:any):Observable<any> { 
  
      // Create form data 
      const formData = new FormData();  
        
      // Store form name as "file" with file data 
      formData.append("file", file, file.name); 
        
      // Make http post request over api 
      // with formData as req 
      return this.http.post(this.baseApiUrl, formData) 
  } 
}
