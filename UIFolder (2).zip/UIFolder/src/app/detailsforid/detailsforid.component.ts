import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ViewDetailsService } from '../view-details/view-details.service';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';

@Component({
  selector: 'app-detailsforid',
  templateUrl: './detailsforid.component.html',
  styleUrl: './detailsforid.component.sass'
})
export class DetailsforidComponent implements OnInit {
  loginForm: any;
  dataValue={};
  cars: any = [
    {value: 'Female', viewValue: 'Female'},
    {value: 'male', viewValue: 'male'},
  ];

  Countries: any = [
    {value: 'India', viewValue: 'India'},
    {value: 'USA', viewValue: 'USA'},
    {value: 'UK', viewValue: 'UK'},
  ];

  States:any=[
    {value: 'Maharashtra', viewValue: 'Maharashtra',country:"India"},
    {value: 'California', viewValue: 'California',country:"USA"},
    {value: 'London', viewValue: 'London',country:"UK"},
    {value: 'Karnataka', viewValue: 'Karnataka',country:"India"},
    
  ];

  city:any=[
    {value: 'Mumbai', viewValue: 'Mumbai',country:"India",state:"Maharashtra"},
    {value: 'Orange county', viewValue: 'Orange county',country:"USA",state:"California"},
  ];
  fileName:any;
  StateSelection:any =[];
  cityselection:any=[];
  constructor(@Inject(MAT_DIALOG_DATA) public data:any,public Restiration:ViewDetailsService,public dialogRef: MatDialogRef<DetailsforidComponent>,) { 
   this.dataValue=data;
   this.fileName=data?.Photo;
  }
  ngOnInit() {
        this.loginForm = new FormGroup({
            firstname: new FormControl(null, Validators.required),
            lastname: new FormControl(),
            gender:new FormControl(),
            ContactNumber:new FormControl(),
            email:new FormControl(),
            designation:new FormControl(),
            dateofBirth:new FormControl(),
            age :new FormControl(),
            Photo:new FormControl(),
            Country: new FormControl(),
            State :new FormControl(),
            City:new FormControl(),
            pincode:new FormControl(),

        });

     this.loginForm.patchValue(this.dataValue);
    }
    
    edit() {
       
      let submitform={
        "firstname":this.loginForm.get("firstname").value,
        "lastname":this.loginForm.get("lastname").value,
        "gender":this.loginForm.get("gender").value,
        "ContactNumber":this.loginForm.get("ContactNumber").value,
        "email":this.loginForm.get("email").value,
        "designation":this.loginForm.get("designation").value,
        "dateofBirth":this.loginForm.get("dateofBirth").value,
        "age":this.loginForm.get("age").value,
        "Photo":this.fileName,
        "Country":this.loginForm.get("Country").value,
        "State":this.loginForm.get("State").value,
        "City":this.loginForm.get("City").value,
        "pincode":this.loginForm.get("pincode").value,
      
      }
      this.apiCall(submitform);
    }


    apiCall(submitform:any){
       this.Restiration.updateData(this.dataValue,submitform).subscribe((data)=>{
        console.log(data);
        this.dialogRef.close(true);

      });

    }

    Cancel(): void {
      this.dialogRef.close();
    }


    hangeState(country:any){
      this.StateSelection = this.States.filter((p :any)=> p.country ===country );
    }
    
    
   
    dateofBirthChange(){
        console.log("event");
    
    }
    
    selectCountry($event :any){
       let country =$event;
    
        this.StateSelection= this.States.filter((entry:any)=> entry.country === country);
        this.cityselection= this.city.filter((entry:any)=> entry.country === country);
    
    }
    
    selectState($event :any){
      let state =$event;
      this.cityselection= this.city.filter((entry:any)=> entry.state === state);
    
    }
    
    selectDOB($event :any){
    let birthdate = new Date($event.value);
    let age=0;
    
      if(birthdate){
        const timeDiff = Math.abs(Date.now() - birthdate.getTime() );
        age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365);
    }
    this.loginForm.get("age").setValue(age);
    }


    onFileSelect(input:any) {

      console.log(input.files);
      if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = (e: any) => {
          console.log('Got here: ', e.target.result);
          this.fileName=e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
      }
    }
    
}
